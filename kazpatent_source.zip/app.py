# app.py
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import requests
from datetime import datetime
import os

app = Flask(__name__, template_folder=os.path.join(os.getcwd(), 'templates'))
CORS(app)

OLLAMA_URL = "http://localhost:11434/api/generate"

# Хранилище сообщений
user_sessions = {}

# Триггеры для онкопациентов
ONCOLOGY_TRIGGERS = {
    'treatment_fear': ['боюсь лечения', 'страшно операция', 'химиотерапия страшно', 'радиация больно'],
    'death_anxiety': ['умру скоро', 'страх смерти', 'не хочу умирать', 'смерть близко'],
    'isolation': ['одиноко', 'никто не понимает', 'все бросили', 'никто рядом'],
    'body_changes': ['изменилось тело', 'выпадают волосы', 'шрамы', 'деформация'],
    'future_fear': ['будущее темно', 'что будет потом', 'не доживу', 'планы рушатся'],
    'family_stress': ['семья страдает', 'тяжесть для родных', 'виню себя перед семьей'],
    'hope_loss': ['нет надежды', 'все бесполезно', 'смысла нет', 'сдаюсь'],
    'pain_concern': ['боль не проходит', 'муки', 'страдания', 'терпеть невмоготу']
}

def detect_oncology_triggers(text):
    """Распознавание онкологических триггеров"""
    text_lower = text.lower()
    detected_triggers = []
    
    for trigger_type, keywords in ONCOLOGY_TRIGGERS.items():
        for keyword in keywords:
            if keyword in text_lower:
                detected_triggers.append(trigger_type)
                break
    
    return list(set(detected_triggers))

def analyze_emotion_with_qwen(text):
    """Анализ эмоций с помощью Qwen через Ollama"""
    prompt = f"""Определи эмоцию из: sad, anxious, happy, angry, scared, hopeless, neutral.
    Текст: "{text}"
    Только эмоция:"""
    
    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": "qwen2.5:7b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "max_tokens": 15
            }
        }, timeout=30)
        
        if response.status_code == 200:
            result = response.json()
            emotion = result.get('response', '').strip().lower()
            valid_emotions = ['sad', 'anxious', 'happy', 'angry', 'scared', 'hopeless', 'neutral']
            return emotion if emotion in valid_emotions else 'neutral'
        else:
            return 'neutral'
    except Exception as e:
        print(f"Ошибка: {e}")
        return 'neutral'

def generate_oncology_support_response(user_message, emotion, triggers, session_history):
    """Генерация короткого поддерживающего ответа на РУССКОМ языке"""
    
    recent_history = session_history[-2:] if len(session_history) > 2 else session_history
    history_text = "\n".join([f"{msg['sender']}: {msg['text']}" for msg in recent_history if msg['sender'] in ['user', 'ai']])
    
    triggers_info = ", ".join(triggers) if triggers else "обычные"
    
    prompt = f"""Ты - психолог для онкопациентов. Отвечай ТОЛЬКО НА РУССКОМ ЯЗЫКЕ, очень кратко (1-2 предложения).

Пациент ({emotion}, триггеры: {triggers_info}): "{user_message}"

Краткий ответ по-русски БЕЗ английских слов:"""
    
    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": "qwen2.5:7b", 
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.7,
                    "max_tokens": 100,
                    "stop": ["\n\n", "Пациент:", "Ты:", "User:", "Assistant:"]
                }
            },
            timeout=45
        )
        
        if response.status_code == 200:
            result = response.json()
            answer = result.get('response', '').strip()
            # Убираем английские слова и иероглифы
            import re
            answer = re.sub(r'[a-zA-Z]', '', answer)  # Убираем латиницу
            answer = ''.join(char for char in answer if ord(char) < 10000 or 'а' <= char <= 'я' or 'А' <= char <= 'Я' or char in '.,!?;:()«»"" ')
            return answer[:300].strip() or "Понимаю вас. Это тяжело, но вы не одни."
        else:
            return "Спасибо за доверие. Я рядом."
            
    except Exception as e:
        print(f"Ошибка: {e}")
        return "Спасибо за доверие. Я рядом."

def get_session_history(session_id):
    if session_id not in user_sessions:
        user_sessions[session_id] = []
    return user_sessions[session_id]

@app.route('/')
def index():
    client_ip = request.environ.get('HTTP_X_FORWARDED_FOR', request.remote_addr)
    print(f"Запрос от IP: {client_ip}")  # Это для отладки
    return render_template('index.html')

@app.route('/api/messages', methods=['GET'])
def get_messages():
    session_id = request.args.get('session_id', 'default')
    return jsonify(get_session_history(session_id))

@app.route('/api/send', methods=['POST'])
def send_message():
    data = request.json
    user_message = data.get('message', '')
    session_id = data.get('session_id', 'default')
    
    if not user_message:
        return jsonify({'success': False, 'error': 'Пустое сообщение'}), 400
    
    session_history = get_session_history(session_id)
    
    user_msg = {
        'id': len(session_history) + 1,
        'sender': 'user',
        'text': user_message,
        'timestamp': datetime.now().isoformat(),
        'emotion': 'analyzing',
        'triggers': []
    }
    session_history.append(user_msg)
    
    triggers = detect_oncology_triggers(user_message)
    user_msg['triggers'] = triggers
    
    emotion = analyze_emotion_with_qwen(user_message)
    user_msg['emotion'] = emotion
    
    ai_response = generate_oncology_support_response(user_message, emotion, triggers, session_history)
    
    ai_msg = {
        'id': len(session_history) + 1,
        'sender': 'ai',
        'text': ai_response,
        'timestamp': datetime.now().isoformat(),
        'emotion': emotion,
        'triggers': triggers
    }
    session_history.append(ai_msg)
    
    return jsonify({
        'success': True,
        'message': ai_msg
    })

@app.route('/api/status', methods=['GET'])
def get_status():
    session_id = request.args.get('session_id', 'default')
    session_history = get_session_history(session_id)
    
    if not session_history:
        return jsonify({'status': 'neutral', 'message': 'Нет данных'})
    
    user_messages = [msg for msg in session_history[-8:] if msg['sender'] == 'user']
    
    if not user_messages:
        return jsonify({'status': 'neutral', 'message': 'Нет данных'})
    
    emotions = [msg.get('emotion', 'neutral') for msg in user_messages]
    all_triggers = []
    for msg in user_messages:
        all_triggers.extend(msg.get('triggers', []))
    
    emotion_counts = {}
    for emo in emotions:
        emotion_counts[emo] = emotion_counts.get(emo, 0) + 1
    
    trigger_counts = {}
    for trigger in all_triggers:
        trigger_counts[trigger] = trigger_counts.get(trigger, 0) + 1
    
    high_risk = emotion_counts.get('hopeless', 0) + emotion_counts.get('scared', 0)
    critical_triggers = ['death_anxiety', 'hope_loss']
    has_critical = any(t in critical_triggers for t in all_triggers)
    
    if high_risk >= 2 or has_critical:
        status = 'critical'
        message = '⚠️ Нужна помощь врача'
    elif high_risk >= 1 or len(all_triggers) >= 3:
        status = 'high'
        message = '🔴 Высокий уровень тревоги'
    elif emotion_counts.get('sad', 0) >= 2 or len(all_triggers) >= 1:
        status = 'moderate'
        message = '🟡 Средняя тревожность'
    else:
        status = 'stable'
        message = '🟢 Состояние удовлетворительное'
    
    return jsonify({
        'status': status,
        'message': message,
        'risk_level': status
    })

if __name__ != '__main__':
   application = app